/****************************************************************
 NAME: usbin.h
 DESC: 
 HISTORY:
 Mar.25.2002:purnnamu: reuse the source of S3C2400X u24xmon 
 ****************************************************************/
#ifndef __USBIN_H__
#define __USBIN_H__

void Ep1Handler(void);
void PrepareEp1Fifo(void);

#endif /*__USBIN_H__*/
